<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package storefront
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> <?php storefront_html_tag_schema(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<?php wp_head(); ?>
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/responsive-calendar.css" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" />
	    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>
	    <script src="<?php echo get_template_directory_uri(); ?>/js/responsive-calendar.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$(".responsive-calendar").responsiveCalendar({
		          	time: '2015-06',
		          	events: {
		            	"2013-06-27": {},
			            "2013-06-28": {}, 
			            "2013-06-29": {},
		            	"2013-06-30": {},
			            "2013-07-01": {}, 
			            "2013-07-02": {},
		            	"2013-07-03": {},
			            "2013-07-04": {}, 
			            "2013-07-05": {},
		            	"2013-07-06": {},
			            "2013-07-07": {}, 
			            "2013-07-08": {},
		            	"2013-07-09": {},
			            "2013-07-10": {}, 
			            "2013-07-11": {},
		            	"2013-07-12": {},
			            "2013-07-13": {}, 
			            "2013-07-14": {},
		            	"2013-07-15": {},
			            "2013-07-16": {}, 
			            "2013-07-17": {},
		            	"2013-07-18": {},
			            "2013-07-19": {}, 
			            "2013-07-20": {},
		            	"2013-07-21": {},
			            "2013-07-22": {}, 
			            "2013-07-23": {},
		            	"2013-07-24": {},
			            "2013-07-25": {}, 
			            "2013-07-26": {},
		            	"2013-07-27": {},
			            "2013-07-28": {}, 
			            "2013-07-29": {},
		            	"2013-07-30": {},
			            "2013-07-31": {}, 
			            "2013-08-01": {}, 
			            "2013-08-02": {},
		            	"2013-08-03": {},
			            "2013-08-04": {}, 
			            "2013-08-05": {},
		            	"2013-08-06": {},
			            "2013-08-07": {}, 
			            "2013-08-08": {},
		            	"2013-08-09": {},
			            "2013-08-10": {}, 
			            "2013-08-11": {},
		            	"2013-08-12": {},
			            "2013-08-13": {}, 
			            "2013-08-14": {},
		            	"2013-08-15": {},
			            "2013-08-16": {}, 
			            "2013-08-17": {},
		            	"2013-08-18": {},
			            "2013-08-19": {}, 
			            "2013-08-20": {},
		            	"2013-08-21": {},
			            "2013-08-22": {}, 
			            "2013-08-23": {},
		            	"2013-08-24": {},
			            "2013-08-25": {}, 
			            "2013-08-26": {},
		            	"2013-08-27": {},
			            "2013-08-28": {}, 
			            "2013-08-29": {},
		            	"2013-08-30": {},
			            "2013-08-31": {}, 
			            "2013-09-01": {}, 
			            "2013-09-02": {},
		            	"2013-09-03": {},
			            "2013-09-04": {}, 
			            "2013-09-05": {},
		            	"2013-09-06": {},
			            "2013-09-07": {}, 
			            "2013-09-08": {},
		            	"2013-09-09": {},
			            "2013-09-10": {}, 
			            "2013-09-11": {},
		            	"2013-09-12": {},
			            "2013-09-13": {}, 
			            "2013-09-14": {},
		            	"2013-09-15": {},
			            "2013-09-16": {}, 
			            "2013-09-17": {},
		            	"2013-09-18": {},
			            "2013-09-19": {}, 
			            "2013-09-20": {},
		            	"2013-09-21": {},
			            "2013-09-22": {}, 
			            "2013-09-23": {},
		            	"2013-09-24": {},
			            "2013-09-25": {}, 
			            "2013-09-26": {},
		            	"2013-09-27": {}
		        	}
		        });

				$( ".btn_ver_todo" ).click(function() {
				  	$( ".responsive-calendar" ).toggleClass( "calendarBoxIntExt", 1000, "easeOutSine" );
				  	$( ".btn_ver_todo" ).toggleClass( "btn_ver_todo_2", 1000, "easeOutSine" );
				});

			    $(".identifica").click(function(){
			        $("#btl-content-login").fadeToggle("slow");
			        $("#btl-content-registration").fadeOut("slow");
			    });

			    $(".registra").click(function(){
			        $("#btl-content-registration").fadeToggle("slow");
			        $("#btl-content-login").fadeOut("slow");
			    });
			});
		</script>
	</head>

	<body <?php body_class(); ?>>
	<div id="page" class="hfeed site">
		<?php
		do_action( 'storefront_before_header' ); ?>
		<header id="masthead" class="site-header" role="banner" <?php if ( get_header_image() != '' ) { echo 'style="background-image: url(' . esc_url( get_header_image() ) . ');"'; } ?>>
			<div class="col-full">
				<?php
				/**
				 * @hooked storefront_skip_links - 0
				 * @hooked storefront_social_icons - 10
				 * @hooked storefront_site_branding - 20
				 * @hooked storefront_secondary_navigation - 30
				 * @hooked storefront_product_search - 40
				 * @hooked storefront_primary_navigation - 50
				 * @hooked storefront_header_cart - 60
				 */
				do_action( 'storefront_header' ); ?>
			</div>
		</header><!-- #masthead -->
		<?php
		/**
		 * @hooked storefront_header_widget_region - 10
		 */
		do_action( 'storefront_before_content' ); ?>
		<div id="content" class="site-content" tabindex="-1">
			<div class="col-full">
			<?php
			/**
			 * @hooked woocommerce_breadcrumb - 10
			 */
			do_action( 'storefront_content_top' ); ?>
